#Veniamin Velikoretskikh veniamin@pdx.edu
#CS302 Fall 2025 Karla Fant

#Black box testing for program #4

import pytest

# SOCIAL MEDIA BASE CLASS
# -------------------------

# tests the constructor with valid input
def test_social_media_constructor_valid():
    profile = SocialMediaProfile("user123", "JohnDoe")
    assert profile.get_user_id() == "user123"
    assert profile.get_username() == "JohnDoe"
    assert isinstance(profile.get_posts(), list)

# tests the constructor with invalid input if ID is empty
def test_social_media_constructor_invalid_userid():
    with pytest.raises(ValueError):
        SocialMediaProfile("", "John")

# tests the constructor with invalid input if username is empty
def test_social_media_constructor_invalid_username():
    with pytest.raises(ValueError):
        SocialMediaProfile("user123", "")

# tests if the add post works 
def test_social_media_add_post():
    p = SocialMediaProfile("u1", "Alice")
    p.add_post("Hello world")
    assert len(p.get_posts()) == 1

# tests if the information is displayed
def test_social_media_display_format():
    p = SocialMediaProfile("u1", "Alice")
    result = p.display()
    assert "User ID:" in result
    assert "Username:" in result


# FACEBOOK TESTS
# -------------------------

# tests the facebook constructor if friend and groups count is correct
def test_facebook_constructor_valid():
    f = FacebookProfile("u1", "Alice", 10, 2)
    assert f.get_friends() == 10
    assert f.get_groups() == 2

# tests if the friend and group count are negative, will raise a error
def test_facebook_constructor_invalid():
    with pytest.raises(ValueError):
        FacebookProfile("u1", "Alice", -1, 5)

# tests if the add post works, should accept content and like count
def test_facebook_add_post():
    f = FacebookProfile("u1", "Alice", 10, 2)
    f.add_facebook_post("Post1", likes=10)
    assert len(f.get_posts()) == 1

# test if the average likes is calculated right
def test_facebook_average_likes():
    f = FacebookProfile("u1", "Alice", 10, 2)
    f.add_facebook_post("A", likes=10)
    f.add_facebook_post("B", likes=20)
    assert f.average_likes() == 15

# tests if the most liked post is returned
def test_facebook_most_liked():
    f = FacebookProfile("u1", "Alice", 10, 2)
    f.add_facebook_post("A", likes=5)
    f.add_facebook_post("B", likes=50)
    assert f.most_liked_post()["likes"] == 50


# INSTAGRAM TESTS
# -------------------------

# tests constructor with valid input
def test_instagram_constructor_valid():
    ig = InstagramProfile("i1", "Zara", 100, 5)
    assert ig.get_followers() == 100

# tests constructor with negative input, should raise an error
def test_instagram_constructor_invalid():
    with pytest.raises(ValueError):
        InstagramProfile("i1", "Zara", -5, 10)

# tests if add post works fine, should have content, hearts, shares
def test_instagram_add_post():
    ig = InstagramProfile("i1", "Zara", 100, 5)
    ig.add_instagram_post("Pic", hearts=10, shares=2)
    assert len(ig.get_posts()) == 1

# tests if the engagement calculation is correct
def test_instagram_engagement_rate():
    ig = InstagramProfile("i1", "Zara", 10, 5)
    ig.add_instagram_post("Pic", hearts=5, shares=5)
    assert ig.engagement_rate() == pytest.approx((5+5)/10)

# tests if the most shared post is returned
def test_instagram_most_shared():
    ig = InstagramProfile("i1", "Zara", 10, 5)
    ig.add_instagram_post("Pic1", hearts=2, shares=1)
    ig.add_instagram_post("Pic2", hearts=3, shares=20)
    assert ig.most_shared()["shares"] == 20


# TIKTOK TESTS
# -------------------------

# tests constructor with valid input
def test_tiktok_constructor_valid():
    tk = TikTokProfile("t1", "Jess", 50)
    assert tk.get_user_id() == "t1"
    assert tk.get_username() == "Jess"
    assert tk.get_watch_time() == 50
    assert isinstance(tk.get_posts(), list)

# tests constructor with negative input, should raise an erro
def test_tiktok_constructor_invalid_watch_time():
    with pytest.raises(ValueError):
        TikTokProfile("t1", "Jess", -10)

# tests add video
def test_tiktok_add_video():
    tk = TikTokProfile("t1", "Jess", 50)
    tk.add_video("Vid1", views=100)
    assert len(tk.get_posts()) == 1

# tests if the correct average is outputted 
def test_tiktok_avg_views():
    tk = TikTokProfile("t1", "Jess", 50)
    tk.add_video("v1", views=10)
    tk.add_video("v2", views=30)
    assert tk.avg_views() == 20

# tests if the top video is outputted
def test_tiktok_top_video():
    tk = TikTokProfile("t1", "Jess", 50)
    tk.add_video("v1", views=10)
    tk.add_video("v2", views=300)
    assert tk.top_video()["views"] == 300



# OPERATOR OVERLOADING
# -------------------------

# tests if the < is working correct with string comparison of the id
def test_less_than_by_userid():
    a = SocialMediaProfile("abc", "A")
    b = SocialMediaProfile("bcd", "B")
    assert (a < b) is True

# tests if the user id's are the same
def test_equals_same_userid():
    a = SocialMediaProfile("abc", "A")
    b = SocialMediaProfile("abc", "B")
    assert (a == b)

# tests if the merge of two profiles of the same class work with the + operator
def test_add_same_type_posts_merged():
    ig1 = InstagramProfile("i1", "Zara", 10, 2)
    ig2 = InstagramProfile("i2", "Kyle", 10, 3)

    ig1.add_instagram_post("A", hearts=10, shares=1)
    ig2.add_instagram_post("B", hearts=20, shares=2)

    merged = ig1 + ig2
    assert len(merged.get_posts()) == 2

# tests if the merge of two different types, should raise an error
def test_add_different_types_error():
    f = FacebookProfile("u1", "Alice", 3, 1)
    i = InstagramProfile("i1", "Zara", 10, 5)
    with pytest.raises(TypeError):
        f + i
